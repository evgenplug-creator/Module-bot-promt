class Server:
    @staticmethod
    def start():
        pass
    
    @staticmethod
    def stop():
        pass
