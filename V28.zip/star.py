from multiprocessing import Process
import subprocess

def run_script(script_name):
    subprocess.run(["python", script_name])

# Укажите нужные файлы для запуска
files = ["core.py", "botuser.py"]

processes = []
for file in files:
    process = Process(target=run_script, args=(file,))
    processes.append(process)
    process.start()

for process in processes:
    process.join()